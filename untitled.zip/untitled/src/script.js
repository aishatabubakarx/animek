// Simple “natural” blinking: random intervals
(function () {
  const svg = document.querySelector('.buddy');
  const eyesGroup = svg.querySelector('.eyes');

  function blinkOnce() {
    eyesGroup.classList.add('blink');
    // Close quickly, open after a short delay
    setTimeout(() => eyesGroup.classList.remove('blink'), 120);
  }

  function scheduleBlink() {
    // Random interval between 2.0s and 5.5s
    const next = 2000 + Math.random() * 3500;
    setTimeout(() => {
      // Sometimes do a double-blink
      if (Math.random() < 0.25) {
        blinkOnce();
        setTimeout(blinkOnce, 180);
      } else {
        blinkOnce();
      }
      scheduleBlink();
    }, next);
  }

  // Start the blinking loop after initial render
  scheduleBlink();

  // Optional: follow the pointer slightly with pupils
  const pupils = Array.from(svg.querySelectorAll('.eyes circle'));
  const basePositions = pupils.map(p => ({
    el: p,
    x: parseFloat(p.getAttribute('cx')),
    y: parseFloat(p.getAttribute('cy'))
  }));

  function movePupils(evt) {
    const rect = svg.getBoundingClientRect();
    const mx = (evt.clientX - rect.left) / rect.width; // 0..1
    const my = (evt.clientY - rect.top) / rect.height; // 0..1
    const range = 2.2; // how far pupils can move

    basePositions.forEach(p => {
      const nx = p.x + (mx - 0.5) * range * 2; // [-range, range]
      const ny = p.y + (my - 0.5) * range * 2;
      p.el.setAttribute('cx', nx.toFixed(2));
      p.el.setAttribute('cy', ny.toFixed(2));
    });
  }

  // Only attach on devices with pointers (avoid jitter on touch)
  window.matchMedia('(pointer: fine)').matches &&
    svg.addEventListener('mousemove', movePupils);
})();
